let commentForm = document.querySelector('.comment-form');
let commentList = document.querySelector('.comment-list');

commentForm.onsubmit = function (evt) {
  evt.preventDefault();
  // Перенесите код сюда

};

let newComment = document.createElement('li');
commentList.append(newComment);
