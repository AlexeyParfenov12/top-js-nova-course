let articles = document.querySelectorAll('.news-block');
// Объявите переменную здесь

for (let article of articles) {
  if (article.dataset.category === 'cats') {
    article.classList.add('highlight');
  }
}

// Добавьте обработчик событий здесь
