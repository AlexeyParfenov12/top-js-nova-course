let commentForm = document.querySelector('.comment-form');
// Объявите переменную здесь

commentForm.onsubmit = function (evt) {
  evt.preventDefault();

};
