let tooltip = document.querySelector('.tooltip');
let closeButton = document.querySelector('.close-button');
let tooltipButtons = document.querySelectorAll('.tooltip-button');
console.log(tooltipButtons[0]);
console.log(tooltipButtons[1]);

tooltipButtons[0].onclick = function () {
  tooltip.classList.add('opened');
};

tooltipButtons[1].onclick = function () {
  tooltip.classList.add('opened');
};

closeButton.onclick = function () {
  tooltip.classList.remove('opened');
};

// Добавьте вывод в консоль сюда
