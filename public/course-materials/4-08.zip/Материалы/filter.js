let articles = document.querySelectorAll('.news-block');

for (let article of articles) {
  // Добавьте условную конструкцию сюда
  article.classList.add('highlight');
}
