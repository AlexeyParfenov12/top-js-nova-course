let upButton = document.querySelector('.up-button');

window.onscroll = function () {
  if (window.pageYOffset > 200) {
    upButton.classList.add('shown');
  } // Добавьте else сюда

};

upButton.onclick = function () {
  window.scrollTo(0, 0);
};
