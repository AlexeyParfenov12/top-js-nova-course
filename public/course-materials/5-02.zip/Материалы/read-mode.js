let longread = document.querySelector('.longread');
// Объявите переменную здесь

longread.style.color = 'purple';
