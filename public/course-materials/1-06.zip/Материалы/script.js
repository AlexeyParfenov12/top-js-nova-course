document.querySelector('.page').classList.remove('light-theme');
