window.onscroll = function () {
  console.log('Скролл детектед!');
};