let tooltip = document.querySelector('.tooltip');
let tooltipButton = document.querySelector('.tooltip-button');
let closeButton = document.querySelector('.close-button');
let tooltipButtons = document.querySelectorAll('.tooltip-button');
console.log(tooltipButtons);


tooltipButton.onclick = function () {
  tooltip.classList.add('opened');
};

closeButton.onclick = function () {
  tooltip.classList.remove('opened');
};

