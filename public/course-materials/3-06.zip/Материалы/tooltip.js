let tooltip = document.querySelector('.tooltip');
let closeButton = document.querySelector('.close-button');
let tooltipButtons = document.querySelectorAll('.tooltip-button');
// Объявите переменную здесь

tooltipButtons[0].onclick = function () {
  // Измените здесь текстовое содержимое элемента
  tooltip.classList.add('opened');
};

tooltipButtons[1].onclick = function () {
  // Измените здесь текстовое содержимое элемента
  tooltip.classList.add('opened');
};

closeButton.onclick = function () {
  tooltip.classList.remove('opened');
};
