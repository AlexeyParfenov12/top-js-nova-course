let password = document.querySelector('.password');
let showPassword = document.querySelector('.show-password');

showPassword.onchange = function () {
  // Добавьте условную конструкцию сюда
  password.type = 'text';
};
