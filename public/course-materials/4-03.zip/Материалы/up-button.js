// Объявите переменную здесь

window.onscroll = function () {
  console.log(window.pageYOffset);
};
