let password = document.querySelector('.password');
// Объявите переменную здесь


password.type = 'text';
