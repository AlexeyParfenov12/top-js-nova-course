let heart = document.querySelector('.heart');
// Объявите переменную здесь

heart.onclick = function () {
  // Добавьте код сюда

  heart.classList.toggle('added');
};
