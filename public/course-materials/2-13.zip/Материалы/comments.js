let commentForm = document.querySelector('.comment-form');
let commentList = document.querySelector('.comment-list');

commentForm.onsubmit = function (evt) {
  evt.preventDefault();

  let newComment = document.createElement('li');
  // Добавьте здесь класс элементу newComment

  commentList.append(newComment);
};
