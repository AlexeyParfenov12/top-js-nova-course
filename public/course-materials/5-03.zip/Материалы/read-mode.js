let longread = document.querySelector('.longread');
let colorSetting = document.querySelector('.color-setting');
// Объявите переменную здесь


colorSetting.onchange = function () {
  longread.style.color = colorSetting.value;
};

// Добавьте обработчик событий сюда
