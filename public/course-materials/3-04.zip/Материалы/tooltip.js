let tooltip = document.querySelector('.tooltip');
let tooltipButton = document.querySelector('.tooltip-button');
let closeButton = document.querySelector('.close-button');
let tooltipButtons = document.querySelectorAll('.tooltip-button');
console.log(tooltipButtons[0]);
console.log(tooltipButtons[1]);

tooltipButton.onclick = function () {
  tooltip.classList.add('opened');
};

// Вставьте код сюда

closeButton.onclick = function () {
  tooltip.classList.remove('opened');
};
