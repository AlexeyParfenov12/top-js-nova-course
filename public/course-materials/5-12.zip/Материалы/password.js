let password = document.querySelector('.password');
let showPassword = document.querySelector('.show-password');
let securityBar = document.querySelector('.security-bar');

showPassword.onchange = function () {
  if (showPassword.checked) {
    password.type = 'text';
  } else {
    password.type = 'password';
  }
};

password.oninput = function () {
  // Объявите переменную здесь
  securityBar.style.width = password.value.length * 10 + '%';
};
